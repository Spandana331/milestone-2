"""
Tests for Milestone 1: Bug Submission Module + Historical Defect KB / RAG pipeline.

Run: `pytest` from the backend/ directory (after scripts/build_index.py has been run).
"""
import io

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.bug_submission import detect_report_type, extract_signals
from app.models import ReportType

client = TestClient(app)


def test_health():
    r = client.get("/")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_detect_report_type_stack_trace():
    text = "java.lang.NullPointerException: x is null\n\tat com.a.B.c(B.java:10)"
    assert detect_report_type(text) == ReportType.STACK_TRACE


def test_detect_report_type_log():
    text = (
        "2026-07-05 10:00:00 INFO started\n"
        "2026-07-05 10:00:01 WARN retrying\n"
        "2026-07-05 10:00:02 ERROR failed\n"
    )
    assert detect_report_type(text) == ReportType.LOG


def test_detect_report_type_free_text():
    text = "The app seems to crash sometimes when I close too many tabs quickly."
    assert detect_report_type(text) == ReportType.FREE_TEXT


def test_extract_signals_from_stack_trace():
    text = "java.lang.NullPointerException: boom\n\tat com.app.Foo.bar(Foo.java:99)"
    signals = extract_signals(text, ReportType.STACK_TRACE)
    assert signals.exception_type == "java.lang.NullPointerException"
    assert signals.file == "Foo.java"
    assert signals.line == 99


def test_submit_bug_report_paste():
    r = client.post(
        "/api/v1/bugs/submit",
        json={
            "title": "Crash on save",
            "report_text": "java.lang.NullPointerException: cache entry is null\n"
                            "\tat com.app.CacheManager.writeToDisk(CacheManager.java:42)",
        },
    )
    assert r.status_code == 200
    data = r.json()
    assert data["report_type"] == "stack_trace"
    assert data["extracted_signals"]["file"] == "CacheManager.java"
    assert isinstance(data["retrieved_matches"], list)


def test_submit_bug_report_empty_text_rejected():
    r = client.post("/api/v1/bugs/submit", json={"report_text": "   "})
    assert r.status_code == 422


def test_submit_bug_report_file_txt():
    file_content = b"App freezes when resizing the window repeatedly."
    r = client.post(
        "/api/v1/bugs/submit-file",
        files={"file": ("report.txt", io.BytesIO(file_content), "text/plain")},
        data={"title": "UI freeze"},
    )
    assert r.status_code == 200
    assert r.json()["report_type"] in ("free_text", "log", "stack_trace")


def test_submit_bug_report_file_rejects_bad_extension():
    r = client.post(
        "/api/v1/bugs/submit-file",
        files={"file": ("report.exe", io.BytesIO(b"binary"), "application/octet-stream")},
    )
    assert r.status_code == 415


def test_kb_search_returns_ranked_matches():
    r = client.post("/api/v1/kb/search", json={"query": "memory leak in cache manager", "top_k": 3})
    assert r.status_code == 200
    matches = r.json()
    assert len(matches) <= 3
    if len(matches) > 1:
        scores = [m["similarity_score"] for m in matches]
        assert scores == sorted(scores, reverse=True)


def test_kb_search_empty_query_rejected():
    r = client.post("/api/v1/kb/search", json={"query": ""})
    assert r.status_code == 422
