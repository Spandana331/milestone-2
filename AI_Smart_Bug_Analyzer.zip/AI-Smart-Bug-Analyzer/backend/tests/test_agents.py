"""
Tests for Milestone 2: Triage Agent, Log Analysis Agent, and multi-agent
orchestration (including the persisted-analysis retrieval endpoint).
"""
from fastapi.testclient import TestClient

from app.agents import log_analysis_agent, triage_agent
from app.main import app
from app.models import ReportType

client = TestClient(app)


# --- Log Analysis Agent -----------------------------------------------------

def test_log_analysis_java_stack_trace():
    text = ("java.lang.NullPointerException: cache entry is null\n"
            "\tat com.app.CacheManager.writeToDisk(CacheManager.java:42)\n"
            "\tat com.app.Main.main(Main.java:10)")
    result = log_analysis_agent.analyze(text, ReportType.STACK_TRACE)
    assert result.exception_type == "java.lang.NullPointerException"
    assert result.affected_code_path == "CacheManager.java"
    assert result.stack_frames[0].line == 42
    assert result.confidence_score > 0.5


def test_log_analysis_python_traceback():
    text = ('Traceback (most recent call last):\n'
            '  File "main.py", line 20, in run\n'
            '    process()\n'
            '  File "worker.py", line 55, in process\n'
            '    return cache[key]\n'
            'KeyError: memory_leak_check\n')
    result = log_analysis_agent.analyze(text, ReportType.STACK_TRACE)
    assert result.exception_type == "KeyError"
    assert result.affected_code_path == "worker.py"  # innermost frame, last in Python trace
    assert result.failure_point == "process"


def test_log_analysis_javascript_error():
    text = ("TypeError: Cannot read properties of undefined (reading 'id')\n"
            "    at getUser (server.js:34:15)\n"
            "    at handler (index.js:10:5)")
    result = log_analysis_agent.analyze(text, ReportType.STACK_TRACE)
    assert result.exception_type == "TypeError"
    assert result.affected_code_path == "server.js"


def test_log_analysis_go_panic():
    text = ("panic: runtime error: index out of range [5] with length 3\n\n"
            "goroutine 1 [running]:\nmain.process(...)\n\t/app/worker.go:27\n")
    result = log_analysis_agent.analyze(text, ReportType.STACK_TRACE)
    assert result.exception_type == "panic"
    assert result.affected_code_path == "/app/worker.go"


def test_log_analysis_plain_log_fallback():
    text = ("2026-07-05 10:22:01 INFO Starting sync job\n"
            "2026-07-05 10:22:05 ERROR ConnectionPool exhausted while syncing\n")
    result = log_analysis_agent.analyze(text, ReportType.LOG)
    assert result.exception_type is None
    assert "ConnectionPool exhausted" in result.error_summary


def test_log_analysis_free_text_low_confidence():
    text = "The settings page shows the wrong username after switching accounts."
    result = log_analysis_agent.analyze(text, ReportType.FREE_TEXT)
    assert result.exception_type is None
    assert result.confidence_score < 0.5


# --- Triage Agent ------------------------------------------------------------

def test_triage_high_confidence_when_signals_agree():
    text = ("java.lang.NullPointerException: cache entry is null\n"
            "\tat com.app.CacheManager.writeToDisk(CacheManager.java:42)")
    log_result = log_analysis_agent.analyze(text, ReportType.STACK_TRACE)
    result = triage_agent.analyze(text, log_result, kb_matches=[])
    assert result.severity.value == "High"
    assert result.priority.value == "P1"
    assert 0.0 <= result.confidence_score <= 1.0


def test_triage_defaults_to_medium_with_no_signals():
    text = "Something happened."
    log_result = log_analysis_agent.analyze(text, ReportType.FREE_TEXT)
    result = triage_agent.analyze(text, log_result, kb_matches=[])
    assert result.severity.value == "Medium"
    assert result.confidence_score < 0.3


def test_triage_severity_priority_mapping_is_consistent():
    from app.models import Priority, Severity
    mapping = {
        Severity.CRITICAL: Priority.P0,
        Severity.HIGH: Priority.P1,
        Severity.MEDIUM: Priority.P2,
        Severity.LOW: Priority.P3,
    }
    assert triage_agent._SEVERITY_TO_PRIORITY == mapping


# --- End-to-end orchestration via the API -----------------------------------

def test_submission_automatically_runs_agent_pipeline():
    r = client.post(
        "/api/v1/bugs/submit",
        json={
            "title": "Crash on save",
            "report_text": "java.lang.NullPointerException: cache entry is null\n"
                            "\tat com.app.CacheManager.writeToDisk(CacheManager.java:42)",
        },
    )
    assert r.status_code == 200
    data = r.json()
    assert data["analysis"] is not None
    assert data["analysis"]["triage"]["severity"] in ("Critical", "High", "Medium", "Low")
    assert data["analysis"]["log_analysis"]["exception_type"] == "java.lang.NullPointerException"


def test_analysis_retrievable_by_submission_id():
    submit_resp = client.post(
        "/api/v1/bugs/submit",
        json={"report_text": "TypeError: undefined is not a function\n    at run (app.js:5:1)"},
    )
    submission_id = submit_resp.json()["submission_id"]

    get_resp = client.get(f"/api/v1/bugs/{submission_id}/analysis")
    assert get_resp.status_code == 200
    assert get_resp.json()["submission_id"] == submission_id


def test_analysis_404_for_unknown_submission_id():
    r = client.get("/api/v1/bugs/does-not-exist/analysis")
    assert r.status_code == 404
