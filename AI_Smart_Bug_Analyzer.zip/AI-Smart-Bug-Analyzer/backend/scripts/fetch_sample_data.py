"""
Builds the historical-defect seed dataset used by the Milestone 1 knowledge
base prototype.

WHY THIS SCRIPT EXISTS (please read):
Milestone 1 asks for the KB to be seeded from the Mozilla/Apache/Eclipse bug
datasets on Kaggle. The development sandbox used to build this prototype only
has network access to package registries (PyPI/npm/GitHub) — it cannot reach
kaggle.com. So this script writes a *schema-matched* sample dataset (same
columns, same categories of bugs) so the rest of the pipeline
(ingest -> chunk -> embed -> index -> retrieve) can be demonstrated and tested
end-to-end today.

TO USE THE REAL DATA: run this on a machine with normal internet access.
    1. pip install kagglehub   (or use the Kaggle CLI)
    2. Uncomment `download_from_kaggle()` below and call it instead of
       `write_seed_csv()`.
    3. Point it at the datasets, e.g.:
         - https://www.kaggle.com/datasets/chaozhuang/mozilla-bug-reports
         - Apache Spark/other Apache project issue exports
         - Eclipse Platform Bugzilla exports
       then map their columns onto: id, source, project, component, title,
       description, severity, status, resolution (see docs/02_System_Architecture.md §2.4).
    4. Re-run scripts/build_index.py — no other code changes needed.
"""
import csv
import random
from pathlib import Path

from app.config import SEED_CSV_PATH

random.seed(42)

FIELDNAMES = ["id", "source", "project", "component", "title", "description",
              "severity", "status", "resolution"]

# Representative, realistic bug categories seen across Mozilla/Apache/Eclipse
# Bugzilla & Jira exports. Hand-authored to match real-world phrasing patterns
# so TF-IDF/embedding retrieval has genuine semantic structure to work with.
_TEMPLATES = [
    dict(category="npe", title="NullPointerException when {action}",
         description="java.lang.NullPointerException at com.{proj}.{comp}.{cls}.{method}({file}.java:{line})\n"
                      "Caused by calling {method} on a null {obj} after {action}.",
         severity="major", resolution="fixed"),
    dict(category="memleak", title="Memory leak in {comp} after repeated {action}",
         description="Heap usage grows unbounded after repeatedly {action}. Profiler shows "
                      "{obj} instances in {comp} are never released, retained by a stale listener.",
         severity="critical", resolution="fixed"),
    dict(category="race", title="Race condition causes intermittent failure during {action}",
         description="Two threads mutate shared {obj} state concurrently during {action} without "
                      "synchronization, leading to intermittent {cls} corruption / crash.",
         severity="critical", resolution="fixed"),
    dict(category="ui_freeze", title="UI freezes/hangs when {action}",
         description="The main thread blocks for several seconds when {action}, because {method} "
                      "performs a synchronous network/disk call for {obj} on the UI thread.",
         severity="major", resolution="fixed"),
    dict(category="build", title="Build fails on clean checkout: {method} not found",
         description="Compilation error: cannot resolve symbol {method} in {comp}. Root cause: "
                      "dependency version mismatch introduced by a recent change to {cls}.",
         severity="blocker", resolution="fixed"),
    dict(category="crash_startup", title="Application crashes on startup after {action}",
         description="Startup crashes with a {cls} in {comp} immediately after {action}; regression "
                      "introduced by an unguarded {obj} initialization order change.",
         severity="blocker", resolution="fixed"),
    dict(category="dup", title="Duplicate: {comp} {cls} already reported",
         description="This looks identical to an earlier report about {comp} raising {cls} during "
                      "{action}. Same stack trace signature.",
         severity="minor", resolution="duplicate"),
    dict(category="wontfix", title="{comp} behaves unexpectedly when {action} (by design)",
         description="Reported behavior in {comp} during {action} is intentional; {obj} is meant to "
                      "reset in this scenario per design doc.",
         severity="trivial", resolution="wontfix"),
    dict(category="perf", title="Performance regression in {comp} during {action}",
         description="{action} now takes significantly longer; {method} was changed to do redundant "
                      "{obj} recomputation on every call instead of caching.",
         severity="major", resolution="fixed"),
    dict(category="config", title="Incorrect default configuration causes {comp} to fail on {action}",
         description="Default config value for {obj} is invalid for {action}, causing {comp} to throw "
                      "{cls} on first use out of the box.",
         severity="minor", resolution="fixed"),
]

_PROJECTS = {
    "mozilla": ["Firefox", "Thunderbird", "Firefox-for-Android"],
    "apache": ["Spark", "Kafka", "Hadoop-HDFS", "Tomcat"],
    "eclipse": ["Eclipse-Platform", "JDT", "PDE"],
}
_COMPONENTS = ["NetworkLayer", "RenderEngine", "Scheduler", "CacheManager",
               "AuthModule", "FileIndexer", "UIToolkit", "BuildSystem",
               "SessionManager", "EventBus"]
_ACTIONS = ["saving a large file", "reconnecting after network loss",
            "switching workspaces", "importing a project", "resizing the window",
            "running a long query", "rotating log files", "parsing a malformed config",
            "closing multiple tabs quickly", "syncing in the background"]
_CLASSES = ["NullPointerException", "IllegalStateException", "IndexOutOfBoundsException",
            "ConcurrentModificationException", "TimeoutException", "OutOfMemoryError"]
_METHODS = ["writeToDisk", "refreshCache", "resolveDependencies", "renderFrame",
            "dispatchEvent", "acquireLock", "loadConfig", "flushBuffer"]
_OBJECTS = ["session", "cache entry", "listener", "connection pool", "buffer",
            "index", "config object", "worker thread"]


def _fill(template: str, **kwargs) -> str:
    return template.format(**kwargs)


def generate_records(n_per_template: int = 6) -> list[dict]:
    records = []
    counter = 1
    for source, projects in _PROJECTS.items():
        for template in _TEMPLATES:
            for _ in range(n_per_template // len(_PROJECTS) + 1):
                proj = random.choice(projects)
                comp = random.choice(_COMPONENTS)
                action = random.choice(_ACTIONS)
                cls = random.choice(_CLASSES)
                method = random.choice(_METHODS)
                obj = random.choice(_OBJECTS)
                fill_kwargs = dict(
                    action=action, comp=comp, cls=cls, method=method, obj=obj,
                    proj=proj.lower().replace("-", ""), file=comp, line=random.randint(10, 900),
                )
                title = _fill(template["title"], **fill_kwargs)
                description = _fill(template["description"], **fill_kwargs)
                status = "closed" if template["resolution"] in ("fixed", "duplicate", "wontfix") else "open"
                records.append({
                    "id": f"{source.upper()[:3]}-{1000 + counter}",
                    "source": source,
                    "project": proj,
                    "component": comp,
                    "title": title,
                    "description": description,
                    "severity": template["severity"],
                    "status": status,
                    "resolution": template["resolution"],
                })
                counter += 1
    return records


def write_seed_csv(path: Path = SEED_CSV_PATH) -> int:
    records = generate_records()
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(records)
    return len(records)


# --- Real-data path (run on a machine with Kaggle access) -------------------
# def download_from_kaggle():
#     import kagglehub
#     path = kagglehub.dataset_download("<owner>/<mozilla-apache-eclipse-bug-dataset>")
#     # then load the CSV(s) at `path`, map columns to FIELDNAMES above, and
#     # write to SEED_CSV_PATH with the same csv.DictWriter pattern.


if __name__ == "__main__":
    count = write_seed_csv()
    print(f"Wrote {count} seed bug records to {SEED_CSV_PATH}")
