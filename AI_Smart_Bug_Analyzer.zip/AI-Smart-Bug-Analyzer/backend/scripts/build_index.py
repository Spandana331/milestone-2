"""
Runs the full Historical Defect Knowledge Base build:
  load seed CSV -> clean -> chunk -> fit embeddings -> build FAISS index -> persist

Run after scripts/fetch_sample_data.py. Re-run any time the seed dataset changes.
"""
from app.config import EMBEDDING_PROVIDER, VECTORIZER_PATH
from app.knowledge_base.embeddings import get_embedding_provider
from app.knowledge_base.ingest import load_bug_records, records_to_chunks
from app.knowledge_base.vector_store import FaissVectorStore


def main():
    print("Loading bug records...")
    records = load_bug_records()
    print(f"  loaded {len(records)} bug records")

    print("Chunking...")
    chunks = records_to_chunks(records)
    print(f"  produced {len(chunks)} chunks")

    print(f"Fitting embedding provider ({EMBEDDING_PROVIDER})...")
    provider = get_embedding_provider(EMBEDDING_PROVIDER)
    texts = [c.text for c in chunks]
    provider.fit(texts)
    vectors = provider.embed(texts)
    print(f"  embedding dimension: {provider.dimension}")

    if EMBEDDING_PROVIDER == "tfidf":
        provider.save(VECTORIZER_PATH)
        print(f"  saved vectorizer -> {VECTORIZER_PATH}")

    print("Building FAISS index...")
    store = FaissVectorStore(dimension=vectors.shape[1])
    chunk_ids = [c.chunk_id for c in chunks]
    metadata = [c.metadata for c in chunks]
    store.add(vectors, chunk_ids, metadata)
    store.save()
    print(f"  index size: {store.index.ntotal} vectors")
    print("Done. Knowledge base ready for retrieval.")


if __name__ == "__main__":
    main()
