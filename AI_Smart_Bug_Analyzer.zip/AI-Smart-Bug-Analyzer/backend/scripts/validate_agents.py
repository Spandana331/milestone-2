"""
Milestone 2, deliverable 4 — Validate Triage and Log Analysis agent accuracy
across varied bug report formats and error types using the seeded dataset.

Two validation sets are used:

1. TRIAGE VALIDATION — every record in the seeded historical dataset
   (data/raw/seed_bug_reports.csv) has a ground-truth severity label
   (blocker/critical/major/minor/trivial). We feed each record's title +
   description through the Triage Agent and compare its predicted severity
   against the (mapped) ground truth.

2. LOG ANALYSIS VALIDATION — a small, hand-built multi-format set covering
   Java, Python, JavaScript, Go, and plain-log reports with known ground
   truth (exception_type, file, line), to check extraction accuracy across
   formats/error types the seeded CSV alone doesn't exercise (it only has
   Java-style traces).

Run: `python scripts/validate_agents.py` (after scripts/build_index.py).
Writes a report to docs/04_Milestone2_Validation_Report.md.
"""
import csv
from pathlib import Path

from app.agents import log_analysis_agent, triage_agent
from app.agents.triage_agent import _LEGACY_SEVERITY_MAP
from app.config import SEED_CSV_PATH, BASE_DIR
from app.knowledge_base.rag_pipeline import RAGPipeline
from app.models import ReportType

REPORT_PATH = BASE_DIR.parent / "docs" / "05_Milestone2_Validation_Report.md"


# ---------------------------------------------------------------------------
# 1. Triage Agent validation over the seeded historical dataset
# ---------------------------------------------------------------------------

def validate_triage() -> dict:
    pipeline = RAGPipeline()
    rows = []
    with open(SEED_CSV_PATH, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    correct = 0
    total = 0
    confusion: dict[tuple[str, str], int] = {}

    for row in rows:
        text = f"{row['title']}\n{row['description']}"
        ground_truth = _LEGACY_SEVERITY_MAP.get(row["severity"].lower())
        if ground_truth is None:
            continue

        matches = pipeline.search(text, top_k=5)
        # Exclude the record itself from its own KB evidence (it's always the
        # nearest match to itself, which would make validation trivially easy).
        matches = [m for m in matches if m.bug_id != row["id"]]

        log_result = log_analysis_agent.analyze(text, ReportType.STACK_TRACE)
        triage_result = triage_agent.analyze(text, log_result, matches)

        total += 1
        predicted = triage_result.severity.value
        key = (ground_truth.value, predicted)
        confusion[key] = confusion.get(key, 0) + 1
        if predicted == ground_truth.value:
            correct += 1

    accuracy = correct / total if total else 0.0
    return {"accuracy": accuracy, "correct": correct, "total": total, "confusion": confusion}


# ---------------------------------------------------------------------------
# 2. Log Analysis Agent validation over a varied hand-built multi-format set
# ---------------------------------------------------------------------------

_LOG_ANALYSIS_TEST_CASES = [
    dict(
        label="Java NPE",
        text="java.lang.NullPointerException: cache entry is null\n"
             "\tat com.app.CacheManager.writeToDisk(CacheManager.java:42)\n"
             "\tat com.app.Main.main(Main.java:10)",
        report_type=ReportType.STACK_TRACE,
        expected_exception="java.lang.NullPointerException",
        expected_file="CacheManager.java",
        expected_line=42,
    ),
    dict(
        label="Java IllegalStateException",
        text="java.lang.IllegalStateException: connection already closed\n"
             "\tat com.app.net.Pool.acquire(Pool.java:88)",
        report_type=ReportType.STACK_TRACE,
        expected_exception="java.lang.IllegalStateException",
        expected_file="Pool.java",
        expected_line=88,
    ),
    dict(
        label="Python KeyError",
        text='Traceback (most recent call last):\n'
             '  File "main.py", line 20, in run\n'
             '    process()\n'
             '  File "worker.py", line 55, in process\n'
             '    return cache[key]\n'
             'KeyError: memory_leak_check\n',
        report_type=ReportType.STACK_TRACE,
        expected_exception="KeyError",
        expected_file="worker.py",
        expected_line=55,
    ),
    dict(
        label="Python ZeroDivisionError",
        text='Traceback (most recent call last):\n'
             '  File "calc.py", line 12, in divide\n'
             '    return a / b\n'
             'ZeroDivisionError: division by zero\n',
        report_type=ReportType.STACK_TRACE,
        expected_exception="ZeroDivisionError",
        expected_file="calc.py",
        expected_line=12,
    ),
    dict(
        label="JavaScript TypeError",
        text="TypeError: Cannot read properties of undefined (reading 'id')\n"
             "    at getUser (server.js:34:15)\n"
             "    at handler (index.js:10:5)",
        report_type=ReportType.STACK_TRACE,
        expected_exception="TypeError",
        expected_file="server.js",
        expected_line=34,
    ),
    dict(
        label="Go panic",
        text="panic: runtime error: index out of range [5] with length 3\n\n"
             "goroutine 1 [running]:\n"
             "main.process(...)\n"
             "\t/app/worker.go:27\n",
        report_type=ReportType.STACK_TRACE,
        expected_exception="panic",
        expected_file="/app/worker.go",
        expected_line=27,
    ),
    dict(
        label="Plain log with ERROR line",
        text="2026-07-05 10:22:01 INFO Starting sync job\n"
             "2026-07-05 10:22:03 WARN Retry attempt 1 for connection pool\n"
             "2026-07-05 10:22:05 ERROR ConnectionPool exhausted while syncing\n",
        report_type=ReportType.LOG,
        expected_exception=None,  # plain logs have no structured exception
        expected_file=None,
        expected_line=None,
    ),
    dict(
        label="Free text (no structure)",
        text="The settings page shows the wrong username after switching accounts.",
        report_type=ReportType.FREE_TEXT,
        expected_exception=None,
        expected_file=None,
        expected_line=None,
    ),
]


def validate_log_analysis() -> dict:
    results = []
    exception_correct = 0
    file_correct = 0
    line_correct = 0
    n = len(_LOG_ANALYSIS_TEST_CASES)

    for case in _LOG_ANALYSIS_TEST_CASES:
        result = log_analysis_agent.analyze(case["text"], case["report_type"])
        exc_ok = (result.exception_type == case["expected_exception"])
        file_ok = (result.affected_code_path == case["expected_file"])
        line_ok = _line_matches(result, case["expected_line"])

        exception_correct += exc_ok
        file_correct += file_ok
        line_correct += line_ok

        results.append({
            "label": case["label"],
            "expected_exception": case["expected_exception"],
            "predicted_exception": result.exception_type,
            "exception_correct": exc_ok,
            "expected_file": case["expected_file"],
            "predicted_file": result.affected_code_path,
            "file_correct": file_ok,
            "line_correct": line_ok,
            "confidence": result.confidence_score,
        })

    return {
        "n": n,
        "exception_accuracy": exception_correct / n,
        "file_accuracy": file_correct / n,
        "line_accuracy": line_correct / n,
        "results": results,
    }


def _line_matches(result, expected_line) -> bool:
    if expected_line is None:
        return not result.stack_frames or result.stack_frames[0].line != expected_line
    return any(f.line == expected_line for f in result.stack_frames) or (
        result.stack_frames and result.stack_frames[0].line == expected_line
    )


# ---------------------------------------------------------------------------
# Report generation
# ---------------------------------------------------------------------------

def write_report(triage_stats: dict, log_stats: dict) -> None:
    lines = []
    lines.append("# Milestone 2 — Agent Validation Report\n")
    lines.append("Generated by `scripts/validate_agents.py`.\n")

    lines.append("## Triage Agent — accuracy on seeded historical dataset\n")
    lines.append(f"- Records evaluated: **{triage_stats['total']}**")
    lines.append(f"- Correct predictions: **{triage_stats['correct']}**")
    lines.append(f"- Accuracy: **{triage_stats['accuracy']:.1%}**\n")
    lines.append("Confusion (ground_truth -> predicted): count\n")
    lines.append("| Ground truth | Predicted | Count |")
    lines.append("|---|---|---|")
    for (gt, pred), count in sorted(triage_stats["confusion"].items()):
        lines.append(f"| {gt} | {pred} | {count} |")

    lines.append("\n## Log Analysis Agent — accuracy across varied formats/error types\n")
    lines.append(f"- Test cases: **{log_stats['n']}** (Java, Python, JavaScript, Go, plain log, free text)")
    lines.append(f"- Exception-type extraction accuracy: **{log_stats['exception_accuracy']:.1%}**")
    lines.append(f"- Affected-file extraction accuracy: **{log_stats['file_accuracy']:.1%}**")
    lines.append(f"- Failure-line extraction accuracy: **{log_stats['line_accuracy']:.1%}**\n")
    lines.append("| Case | Expected exception | Predicted | Correct? | Expected file | Predicted file | Correct? |")
    lines.append("|---|---|---|---|---|---|---|")
    for r in log_stats["results"]:
        lines.append(
            f"| {r['label']} | {r['expected_exception']} | {r['predicted_exception']} | "
            f"{'✅' if r['exception_correct'] else '❌'} | {r['expected_file']} | {r['predicted_file']} | "
            f"{'✅' if r['file_correct'] else '❌'} |"
        )

    lines.append("\n## Notes / known limitations\n")
    lines.append(
        "- The Triage Agent's KB signal is only as good as Milestone 1's TF-IDF retrieval; "
        "swapping in dense embeddings (see docs/03_Tech_Stack.md) should improve accuracy on "
        "paraphrased reports that share little vocabulary with historical ones."
    )
    lines.append(
        "- The seeded dataset is template-generated (see scripts/fetch_sample_data.py), so its "
        "vocabulary is more regular than real-world bug reports — treat the Triage accuracy above "
        "as an upper bound, not a real-world guarantee."
    )
    lines.append(
        "- The Log Analysis Agent recognizes Java, Python, JavaScript/TypeScript, and Go stack-trace "
        "grammars, plus a plain-log/free-text fallback. Additional languages can be added by dropping "
        "a new `_parse_<language>` function into `app/agents/log_analysis_agent.py`."
    )

    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")


def main():
    print("Validating Triage Agent against seeded historical dataset...")
    triage_stats = validate_triage()
    print(f"  Triage accuracy: {triage_stats['accuracy']:.1%} "
          f"({triage_stats['correct']}/{triage_stats['total']})")

    print("Validating Log Analysis Agent across varied formats...")
    log_stats = validate_log_analysis()
    print(f"  Exception accuracy: {log_stats['exception_accuracy']:.1%}")
    print(f"  File accuracy: {log_stats['file_accuracy']:.1%}")
    print(f"  Line accuracy: {log_stats['line_accuracy']:.1%}")

    write_report(triage_stats, log_stats)
    print(f"\nReport written to {REPORT_PATH}")


if __name__ == "__main__":
    main()
