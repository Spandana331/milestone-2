"""
AI Smart Bug Analyzer & Fix Advisor — Milestone 1 API

Wires up:
  - Bug Submission Module     -> /api/v1/bugs/*
  - Historical Defect KB/RAG  -> /api/v1/kb/*
"""
from fastapi import APIRouter, FastAPI, HTTPException

from app.bug_submission import router as bug_submission_router, get_rag_pipeline
from app.models import KBSearchRequest, MatchedDefect

app = FastAPI(
    title="AI Smart Bug Analyzer & Fix Advisor",
    description="Infosys Springboard Internship — Milestone 1 prototype API",
    version="0.1.0-milestone1",
)

kb_router = APIRouter(prefix="/api/v1/kb", tags=["Historical Defect Knowledge Base (RAG)"])


@kb_router.post("/search", response_model=list[MatchedDefect])
def search_knowledge_base(payload: KBSearchRequest) -> list[MatchedDefect]:
    """Directly query the RAG knowledge base (used internally by bug submission,
    exposed here too so agents/UI can query it independently in later milestones)."""
    try:
        pipeline = get_rag_pipeline()
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return pipeline.search(payload.query, top_k=payload.top_k)


@app.get("/", tags=["Health"])
def root():
    return {
        "status": "ok",
        "project": "AI Smart Bug Analyzer & Fix Advisor",
        "milestone": 1,
        "docs": "/docs",
    }


app.include_router(bug_submission_router)
app.include_router(kb_router)
