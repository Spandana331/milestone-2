"""
Pydantic schemas — mirrors the data model defined in
docs/02_System_Architecture.md §2.4.
"""
from __future__ import annotations
from datetime import datetime, timezone
from enum import Enum
from typing import Optional
from uuid import uuid4

from pydantic import BaseModel, Field


class ReportType(str, Enum):
    FREE_TEXT = "free_text"
    STACK_TRACE = "stack_trace"
    LOG = "log"


class BugSubmissionRequest(BaseModel):
    title: Optional[str] = None
    report_text: str = Field(..., min_length=1, description="Bug report, stack trace, or log text")
    report_type: Optional[ReportType] = Field(
        None, description="If omitted, the module auto-detects the type."
    )


class ExtractedSignals(BaseModel):
    exception_type: Optional[str] = None
    top_frame: Optional[str] = None
    file: Optional[str] = None
    line: Optional[int] = None
    error_line_count: int = 0
    warning_line_count: int = 0


class MatchedDefect(BaseModel):
    bug_id: str
    source: str
    project: str
    component: str
    title: str
    severity: str
    status: str
    resolution: str
    similarity_score: float


class SubmittedReport(BaseModel):
    submission_id: str = Field(default_factory=lambda: str(uuid4()))
    title: Optional[str] = None
    report_text: str
    report_type: ReportType
    extracted_signals: ExtractedSignals
    submitted_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    retrieved_matches: list[MatchedDefect] = Field(default_factory=list)
    analysis: Optional["CombinedAnalysis"] = None


class KBSearchRequest(BaseModel):
    query: str = Field(..., min_length=1)
    top_k: int = 5


# ---------------------------------------------------------------------------
# Milestone 2 — Triage Agent + Log Analysis Agent + Multi-Agent Orchestration
# ---------------------------------------------------------------------------

class Severity(str, Enum):
    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


class Priority(str, Enum):
    P0 = "P0"
    P1 = "P1"
    P2 = "P2"
    P3 = "P3"


class TriageResult(BaseModel):
    severity: Severity
    priority: Priority
    affected_component: str
    confidence_score: float = Field(..., ge=0.0, le=1.0)
    reasoning: str


class StackFrame(BaseModel):
    class_or_function: Optional[str] = None
    file: Optional[str] = None
    line: Optional[int] = None
    raw: str


class LogAnalysisResult(BaseModel):
    exception_type: Optional[str] = None
    failure_point: Optional[str] = None
    affected_code_path: Optional[str] = None
    stack_frames: list[StackFrame] = Field(default_factory=list)
    error_summary: str
    confidence_score: float = Field(..., ge=0.0, le=1.0)


class CombinedAnalysis(BaseModel):
    """
    The structured, persisted output of Milestone 2 — this is exactly what
    Milestone 3's Root Cause / Duplicate Detection / Remediation agents will
    read, so its shape is considered a stable contract.
    """
    submission_id: str
    triage: TriageResult
    log_analysis: LogAnalysisResult
    analyzed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


SubmittedReport.model_rebuild()
