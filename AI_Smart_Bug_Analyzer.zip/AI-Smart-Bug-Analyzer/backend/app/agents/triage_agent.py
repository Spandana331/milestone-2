"""
Milestone 2 — Triage Agent

Classifies a submitted bug by severity (Critical/High/Medium/Low) and derived
priority (P0-P3), guesses the affected component, and returns a confidence
score with human-readable reasoning explaining which signals drove the call.

Design (see docs/04_Milestone2_Agents.md for the full write-up):
Three independent signals are combined by weighted vote so no single noisy
signal can dominate:
  1. Keyword signal   — severity-indicative language in the report text.
  2. Exception signal — the exception/error type extracted by the Log
                         Analysis Agent (a known mapping of exception class
                         -> typical severity).
  3. KB signal         — the majority severity/component among the top-k
                         historical defects retrieved by the RAG pipeline
                         (Milestone 1), weighted by similarity score.
Confidence = how much the three signals agree, not just "how strong" any one
signal is — full agreement is the only way to reach high confidence.
"""
from collections import Counter

from app.models import LogAnalysisResult, MatchedDefect, Priority, Severity, TriageResult

_SEVERITY_ORDER = [Severity.LOW, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL]

_SEVERITY_TO_PRIORITY = {
    Severity.CRITICAL: Priority.P0,
    Severity.HIGH: Priority.P1,
    Severity.MEDIUM: Priority.P2,
    Severity.LOW: Priority.P3,
}

# Historical dataset uses Bugzilla/Jira-style labels; map them onto our scale.
_LEGACY_SEVERITY_MAP = {
    "blocker": Severity.CRITICAL,
    "critical": Severity.CRITICAL,
    "major": Severity.HIGH,
    "minor": Severity.MEDIUM,
    "trivial": Severity.LOW,
}

_KEYWORD_SEVERITY = {
    Severity.CRITICAL: ["data loss", "security", "corrupt", "deadlock", "unrecoverable",
                         "outofmemory", "out of memory", "vulnerability", "crash on startup"],
    Severity.HIGH: ["crash", "exception", "fails", "failure", "null pointer",
                     "race condition", "timeout", "hang", "freeze"],
    Severity.MEDIUM: ["slow", "regression", "unexpected", "incorrect", "intermittent"],
    Severity.LOW: ["cosmetic", "typo", "minor", "trivial", "ui glitch", "by design"],
}

_EXCEPTION_SEVERITY = {
    "OutOfMemoryError": Severity.CRITICAL,
    "SecurityException": Severity.CRITICAL,
    "panic": Severity.CRITICAL,
    "NullPointerException": Severity.HIGH,
    "IllegalStateException": Severity.HIGH,
    "ConcurrentModificationException": Severity.HIGH,
    "IndexOutOfBoundsException": Severity.HIGH,
    "TimeoutException": Severity.MEDIUM,
    "IOError": Severity.MEDIUM,
    "ConfigException": Severity.MEDIUM,
}


def _keyword_signal(text: str) -> Severity | None:
    lowered = text.lower()
    # check from most to least severe so e.g. "crash" doesn't get shadowed by "minor" elsewhere
    for severity in reversed(_SEVERITY_ORDER):
        for kw in _KEYWORD_SEVERITY[severity]:
            if kw in lowered:
                return severity
    return None


def _exception_signal(log_analysis: LogAnalysisResult) -> Severity | None:
    if not log_analysis.exception_type:
        return None
    for known_exc, severity in _EXCEPTION_SEVERITY.items():
        if known_exc.lower() in log_analysis.exception_type.lower():
            return severity
    return None


def _kb_signal(matches: list[MatchedDefect]) -> tuple[Severity | None, str | None]:
    if not matches:
        return None, None
    sev_votes: Counter = Counter()
    comp_votes: Counter = Counter()
    for m in matches:
        weight = max(m.similarity_score, 0.01)
        mapped = _LEGACY_SEVERITY_MAP.get(m.severity.lower())
        if mapped:
            sev_votes[mapped] += weight
        comp_votes[m.component] += weight
    severity = sev_votes.most_common(1)[0][0] if sev_votes else None
    component = comp_votes.most_common(1)[0][0] if comp_votes else None
    return severity, component


def analyze(report_text: str, log_analysis: LogAnalysisResult,
            kb_matches: list[MatchedDefect]) -> TriageResult:
    keyword_sev = _keyword_signal(report_text)
    exception_sev = _exception_signal(log_analysis)
    kb_sev, kb_component = _kb_signal(kb_matches)

    signals = [s for s in (keyword_sev, exception_sev, kb_sev) if s is not None]

    named_signals = []
    if keyword_sev:
        named_signals.append((f"report text contains language typical of {keyword_sev.value} bugs",
                               keyword_sev))
    if exception_sev:
        named_signals.append((f"exception type '{log_analysis.exception_type}' is "
                               f"historically {exception_sev.value}", exception_sev))
    if kb_sev:
        named_signals.append(("a majority of similar historical defects retrieved from "
                               f"the knowledge base were {kb_sev.value}", kb_sev))

    if not signals:
        final_severity = Severity.MEDIUM  # neutral default when nothing fires
        confidence = 0.2
        reasoning = "No strong severity signals found; defaulted to Medium."
    else:
        votes = Counter(signals)
        top_count = max(votes.values())
        tied = [sev for sev, count in votes.items() if count == top_count]
        # Tie-break policy: prefer the more severe outcome — safer to
        # over-triage than under-triage a real bug.
        final_severity = max(tied, key=lambda s: _SEVERITY_ORDER.index(s))
        is_tie = len(tied) > 1
        agreement = votes[final_severity] / len(signals)
        confidence = round(min(0.95, 0.35 + 0.35 * agreement + 0.1 * len(signals)), 2)

        supporting = [text for text, sev in named_signals if sev == final_severity]
        conflicting = [text for text, sev in named_signals if sev != final_severity]

        reasoning = f"Severity set to {final_severity.value} because " + "; ".join(supporting) + "."
        if conflicting:
            tie_note = " (tie broken toward the more cautious/higher severity)" if is_tie else ""
            reasoning += f" Note: {'; '.join(conflicting)}, which disagreed{tie_note}."

    affected_component = kb_component or log_analysis.affected_code_path or "Unknown"

    return TriageResult(
        severity=final_severity,
        priority=_SEVERITY_TO_PRIORITY[final_severity],
        affected_component=affected_component,
        confidence_score=confidence,
        reasoning=reasoning,
    )
