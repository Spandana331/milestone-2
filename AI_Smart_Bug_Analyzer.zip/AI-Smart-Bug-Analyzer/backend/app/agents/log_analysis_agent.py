"""
Milestone 2 — Log Analysis Agent

Parses stack traces and error/log messages, identifies the exception type,
the failure point (the frame where the error actually originated), the
affected code path (file), and returns everything as structured frames so
downstream agents (Root Cause, Remediation — Milestone 3) can consume it
directly without re-parsing raw text.

Supports the stack-trace/error-message formats we designed for in
docs/01_Research_Notes.md §1.2: Java, Python, JavaScript/Node, and Go, plus
a fallback path for plain logs (ERROR/WARN lines) and free text.
"""
import re

from app.models import LogAnalysisResult, StackFrame, ReportType

# --- Per-language frame patterns -------------------------------------------

_JAVA_FRAME = re.compile(r"at\s+([\w.$]+)\(([\w.]+):(\d+)\)")
_JAVA_EXCEPTION = re.compile(r"^([\w.$]*(?:Exception|Error))(?::\s*(.*))?", re.MULTILINE)

_PYTHON_FRAME = re.compile(r'File "([^"]+)", line (\d+), in ([\w_.<>]+)')
_PYTHON_EXCEPTION = re.compile(r"^(\w+(?:Error|Exception|Warning)):?\s*(.*)$", re.MULTILINE)

_JS_FRAME = re.compile(r"at\s+([\w.$<>]+)?\s*\(?([\w./\\-]+\.(?:js|ts)):(\d+):(\d+)\)?")
_JS_EXCEPTION = re.compile(r"^(\w*Error):\s*(.*)$", re.MULTILINE)

_GO_FRAME = re.compile(r"([\w./]+\.go):(\d+)")
_GO_PANIC = re.compile(r"panic:\s*(.*)")

_LOG_LEVEL_LINE = re.compile(
    r"^\s*(?:\[?\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}\]?|\d{2}:\d{2}:\d{2})?\s*"
    r"(ERROR|FATAL|WARN|WARNING)\s*(.*)$",
    re.MULTILINE,
)


def _parse_java(text: str) -> LogAnalysisResult | None:
    frames_raw = _JAVA_FRAME.findall(text)
    if not frames_raw:
        return None
    exc_match = _JAVA_EXCEPTION.search(text)
    exception_type = exc_match.group(1) if exc_match else None
    frames = [
        StackFrame(class_or_function=m[0], file=m[1], line=int(m[2]),
                   raw=f"at {m[0]}({m[1]}:{m[2]})")
        for m in frames_raw
    ]
    top = frames[0]
    return LogAnalysisResult(
        exception_type=exception_type,
        failure_point=top.class_or_function,
        affected_code_path=top.file,
        stack_frames=frames,
        error_summary=f"{exception_type or 'Exception'} originating at {top.class_or_function} "
                       f"({top.file}:{top.line})",
        confidence_score=0.9 if exception_type else 0.6,
    )


def _parse_python(text: str) -> LogAnalysisResult | None:
    frames_raw = _PYTHON_FRAME.findall(text)
    if not frames_raw:
        return None
    exc_match = None
    for m in _PYTHON_EXCEPTION.finditer(text):
        exc_match = m  # last match = the actual raised exception, per traceback format
    exception_type = exc_match.group(1) if exc_match else None
    frames = [
        StackFrame(class_or_function=m[2], file=m[0], line=int(m[1]),
                   raw=f'File "{m[0]}", line {m[1]}, in {m[2]}')
        for m in frames_raw
    ]
    top = frames[-1]  # innermost frame is last in a Python traceback
    return LogAnalysisResult(
        exception_type=exception_type,
        failure_point=top.class_or_function,
        affected_code_path=top.file,
        stack_frames=frames,
        error_summary=f"{exception_type or 'Exception'} originating at {top.class_or_function} "
                       f"({top.file}:{top.line})",
        confidence_score=0.9 if exception_type else 0.6,
    )


def _parse_javascript(text: str) -> LogAnalysisResult | None:
    frames_raw = _JS_FRAME.findall(text)
    if not frames_raw:
        return None
    exc_match = _JS_EXCEPTION.search(text)
    exception_type = exc_match.group(1) if exc_match else None
    frames = [
        StackFrame(class_or_function=m[0] or None, file=m[1], line=int(m[2]),
                   raw=f"at {m[0]} ({m[1]}:{m[2]}:{m[3]})")
        for m in frames_raw
    ]
    top = frames[0]
    return LogAnalysisResult(
        exception_type=exception_type,
        failure_point=top.class_or_function or top.file,
        affected_code_path=top.file,
        stack_frames=frames,
        error_summary=f"{exception_type or 'Error'} originating at "
                       f"{top.class_or_function or top.file} ({top.file}:{top.line})",
        confidence_score=0.85 if exception_type else 0.55,
    )


def _parse_go(text: str) -> LogAnalysisResult | None:
    frames_raw = _GO_FRAME.findall(text)
    panic_match = _GO_PANIC.search(text)
    if not frames_raw and not panic_match:
        return None
    frames = [StackFrame(file=m[0], line=int(m[1]), raw=f"{m[0]}:{m[1]}") for m in frames_raw]
    top = frames[0] if frames else None
    exception_type = "panic" if panic_match else None
    summary_detail = panic_match.group(1) if panic_match else "unknown panic"
    return LogAnalysisResult(
        exception_type=exception_type,
        failure_point=top.file if top else None,
        affected_code_path=top.file if top else None,
        stack_frames=frames,
        error_summary=f"Go panic: {summary_detail}",
        confidence_score=0.8 if panic_match else 0.5,
    )


def _parse_log_lines(text: str) -> LogAnalysisResult:
    hits = _LOG_LEVEL_LINE.findall(text)
    error_hits = [h for h in hits if h[0] in ("ERROR", "FATAL")]
    chosen = error_hits[0] if error_hits else (hits[0] if hits else None)
    summary = chosen[1].strip() if chosen else "No ERROR/FATAL lines found; free-text report."
    return LogAnalysisResult(
        exception_type=None,
        failure_point=None,
        affected_code_path=None,
        stack_frames=[],
        error_summary=summary[:300],
        confidence_score=0.4 if chosen else 0.2,
    )


_LANGUAGE_PARSERS = [_parse_java, _parse_python, _parse_javascript, _parse_go]


def analyze(report_text: str, report_type: ReportType) -> LogAnalysisResult:
    """
    Try each language-specific parser in turn (a report can only match one
    language's *frame* grammar in practice); fall back to log-line / free-text
    handling if no structured stack trace is found.
    """
    if report_type in (ReportType.STACK_TRACE, ReportType.LOG):
        for parser in _LANGUAGE_PARSERS:
            result = parser(report_text)
            if result is not None:
                return result

    return _parse_log_lines(report_text)
