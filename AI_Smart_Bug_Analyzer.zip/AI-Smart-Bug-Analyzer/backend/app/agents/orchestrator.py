"""
Milestone 2 — Multi-Agent Orchestration

Runs the Triage Agent and Log Analysis Agent on every submission (Log
Analysis runs first since Triage consumes its output — see
docs/02_System_Architecture.md §2.3 for why this order was chosen), combines
both outputs into a single `CombinedAnalysis`, and persists it so Milestone 3
agents (Root Cause, Duplicate Detection, Remediation) can read it directly
without re-running analysis or re-parsing raw text.
"""
import json
from pathlib import Path

from app.agents import log_analysis_agent, triage_agent
from app.config import PROCESSED_DATA_DIR
from app.models import CombinedAnalysis, MatchedDefect, ReportType

ANALYSES_DIR = PROCESSED_DATA_DIR / "analyses"
ANALYSES_DIR.mkdir(parents=True, exist_ok=True)


def run_pipeline(submission_id: str, report_text: str, report_type: ReportType,
                  kb_matches: list[MatchedDefect]) -> CombinedAnalysis:
    log_result = log_analysis_agent.analyze(report_text, report_type)
    triage_result = triage_agent.analyze(report_text, log_result, kb_matches)

    analysis = CombinedAnalysis(
        submission_id=submission_id,
        triage=triage_result,
        log_analysis=log_result,
    )
    _persist(analysis)
    return analysis


def _persist(analysis: CombinedAnalysis) -> None:
    path = ANALYSES_DIR / f"{analysis.submission_id}.json"
    path.write_text(analysis.model_dump_json(indent=2), encoding="utf-8")


def load_analysis(submission_id: str) -> CombinedAnalysis | None:
    path = ANALYSES_DIR / f"{submission_id}.json"
    if not path.exists():
        return None
    return CombinedAnalysis.model_validate_json(path.read_text(encoding="utf-8"))
