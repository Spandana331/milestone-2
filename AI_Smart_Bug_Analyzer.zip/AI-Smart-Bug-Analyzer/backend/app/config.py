"""
Central configuration for AI Smart Bug Analyzer & Fix Advisor.

Swapping the embedding provider or vector store backend for production is a
one-line change here — no other module needs to change.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"

RAW_DATA_DIR.mkdir(parents=True, exist_ok=True)
PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)

SEED_CSV_PATH = RAW_DATA_DIR / "seed_bug_reports.csv"
INDEX_PATH = PROCESSED_DATA_DIR / "faiss.index"
METADATA_PATH = PROCESSED_DATA_DIR / "chunk_metadata.json"
VECTORIZER_PATH = PROCESSED_DATA_DIR / "tfidf_vectorizer.pkl"

# Embedding provider: "tfidf" (default, offline/no-download) or
# "sentence_transformer" (requires huggingface.co access — see docs/03_Tech_Stack.md)
EMBEDDING_PROVIDER = os.environ.get("EMBEDDING_PROVIDER", "tfidf")
SENTENCE_TRANSFORMER_MODEL = "all-MiniLM-L6-v2"

# Chunking
CHUNK_SIZE_TOKENS = 300
CHUNK_OVERLAP_TOKENS = 50

# Retrieval
DEFAULT_TOP_K = 5

# File upload
ALLOWED_UPLOAD_EXTENSIONS = {".txt", ".log"}
MAX_UPLOAD_SIZE_BYTES = 2 * 1024 * 1024  # 2 MB
