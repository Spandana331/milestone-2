"""
Module 2, part C — Vector store: a thin, swappable wrapper around FAISS.

Stores L2-normalized vectors in an IndexFlatIP (inner product), which is
equivalent to exact cosine-similarity nearest-neighbor search once vectors are
normalized (as our EmbeddingProviders always return).
"""
import json
from pathlib import Path

import faiss
import numpy as np

from app.config import INDEX_PATH, METADATA_PATH


class FaissVectorStore:
    def __init__(self, dimension: int):
        self.dimension = dimension
        self.index = faiss.IndexFlatIP(dimension)
        self.chunk_ids: list[str] = []
        self.metadata: dict[str, dict] = {}

    def add(self, vectors: np.ndarray, chunk_ids: list[str], metadata: list[dict]) -> None:
        assert vectors.shape[0] == len(chunk_ids) == len(metadata)
        self.index.add(vectors)
        self.chunk_ids.extend(chunk_ids)
        for cid, meta in zip(chunk_ids, metadata):
            self.metadata[cid] = meta

    def search(self, query_vector: np.ndarray, top_k: int = 5) -> list[tuple[str, float, dict]]:
        if query_vector.ndim == 1:
            query_vector = query_vector.reshape(1, -1)
        scores, indices = self.index.search(query_vector, top_k)
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            chunk_id = self.chunk_ids[idx]
            results.append((chunk_id, float(score), self.metadata[chunk_id]))
        return results

    def save(self, index_path: Path = INDEX_PATH, metadata_path: Path = METADATA_PATH) -> None:
        faiss.write_index(self.index, str(index_path))
        with open(metadata_path, "w", encoding="utf-8") as f:
            json.dump(
                {"chunk_ids": self.chunk_ids, "metadata": self.metadata, "dimension": self.dimension},
                f,
            )

    @classmethod
    def load(cls, index_path: Path = INDEX_PATH, metadata_path: Path = METADATA_PATH) -> "FaissVectorStore":
        if not index_path.exists() or not metadata_path.exists():
            raise FileNotFoundError(
                "Vector index not found. Run `python scripts/build_index.py` first."
            )
        with open(metadata_path, "r", encoding="utf-8") as f:
            payload = json.load(f)
        store = cls(dimension=payload["dimension"])
        store.index = faiss.read_index(str(index_path))
        store.chunk_ids = payload["chunk_ids"]
        store.metadata = payload["metadata"]
        return store
