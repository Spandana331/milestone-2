"""
Module 2, part B — Embeddings.

`EmbeddingProvider` is the interface every downstream component (vector_store,
rag_pipeline) depends on. Two implementations are given:

- TfidfEmbeddingProvider (default): fits a TF-IDF vectorizer over the corpus.
  Zero model download — works fully offline, which is why it's the Milestone 1
  default in this sandbox (see docs/03_Tech_Stack.md).
- SentenceTransformerEmbeddingProvider: dense neural embeddings via
  `sentence-transformers`. Requires downloading a pretrained model from
  Hugging Face the first time it runs, so enable it only in an environment
  with that network access (uncomment the dependency in requirements.txt and
  set EMBEDDING_PROVIDER=sentence_transformer in config.py / env).

Swapping between them never requires touching vector_store.py or
rag_pipeline.py — both just call `.embed(texts) -> np.ndarray`.
"""
from __future__ import annotations

import pickle
from abc import ABC, abstractmethod
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize

from app.config import VECTORIZER_PATH


class EmbeddingProvider(ABC):
    @abstractmethod
    def fit(self, texts: list[str]) -> None:
        """Fit/train the provider on the full corpus (only needed for TF-IDF)."""

    @abstractmethod
    def embed(self, texts: list[str]) -> np.ndarray:
        """Return an (n_texts, dim) L2-normalized float32 embedding matrix."""

    @abstractmethod
    def save(self, path: Path) -> None: ...

    @abstractmethod
    def load(self, path: Path) -> None: ...

    @property
    @abstractmethod
    def dimension(self) -> int: ...


class TfidfEmbeddingProvider(EmbeddingProvider):
    def __init__(self, max_features: int = 5000):
        self.vectorizer = TfidfVectorizer(
            max_features=max_features,
            stop_words="english",
            ngram_range=(1, 2),
        )
        self._dim: int | None = None

    def fit(self, texts: list[str]) -> None:
        self.vectorizer.fit(texts)
        self._dim = len(self.vectorizer.vocabulary_)

    def embed(self, texts: list[str]) -> np.ndarray:
        matrix = self.vectorizer.transform(texts).toarray().astype("float32")
        matrix = normalize(matrix, norm="l2", axis=1)
        return matrix

    def save(self, path: Path = VECTORIZER_PATH) -> None:
        with open(path, "wb") as f:
            pickle.dump(self.vectorizer, f)

    def load(self, path: Path = VECTORIZER_PATH) -> None:
        with open(path, "rb") as f:
            self.vectorizer = pickle.load(f)
        self._dim = len(self.vectorizer.vocabulary_)

    @property
    def dimension(self) -> int:
        if self._dim is None:
            raise RuntimeError("Provider not fitted/loaded yet.")
        return self._dim


class SentenceTransformerEmbeddingProvider(EmbeddingProvider):
    """
    Dense embedding provider using sentence-transformers.
    NOTE: requires `pip install sentence-transformers` and Hugging Face network
    access on first run to download the model weights. Not used by default in
    this sandbox — see module docstring.
    """

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer  # deferred import
        self.model = SentenceTransformer(model_name)
        self._dim = self.model.get_sentence_embedding_dimension()

    def fit(self, texts: list[str]) -> None:
        pass  # pretrained model, nothing to fit

    def embed(self, texts: list[str]) -> np.ndarray:
        vectors = self.model.encode(texts, normalize_embeddings=True)
        return np.asarray(vectors, dtype="float32")

    def save(self, path: Path) -> None:
        pass  # model is loaded from HF hub each time; nothing local to persist

    def load(self, path: Path) -> None:
        pass

    @property
    def dimension(self) -> int:
        return self._dim


def get_embedding_provider(provider_name: str) -> EmbeddingProvider:
    if provider_name == "tfidf":
        return TfidfEmbeddingProvider()
    if provider_name == "sentence_transformer":
        return SentenceTransformerEmbeddingProvider()
    raise ValueError(f"Unknown embedding provider: {provider_name}")
