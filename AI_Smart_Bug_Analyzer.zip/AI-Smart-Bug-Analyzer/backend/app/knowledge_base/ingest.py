"""
Module 2, part A — Ingestion: load raw historical bug data, clean it, and
split it into chunks ready for embedding.

Expects a CSV at config.SEED_CSV_PATH with columns:
id, source, project, component, title, description, severity, status, resolution

See scripts/fetch_sample_data.py for how this CSV is produced (and how to
swap in the real Mozilla/Apache/Eclipse Kaggle datasets).
"""
import csv
import re
from dataclasses import dataclass, field
from pathlib import Path

from app.config import SEED_CSV_PATH, CHUNK_SIZE_TOKENS, CHUNK_OVERLAP_TOKENS


@dataclass
class BugRecord:
    id: str
    source: str
    project: str
    component: str
    title: str
    description: str
    severity: str
    status: str
    resolution: str


@dataclass
class Chunk:
    chunk_id: str
    bug_id: str
    text: str
    metadata: dict = field(default_factory=dict)


def clean_text(text: str) -> str:
    """Basic normalization: collapse whitespace, strip control characters."""
    text = re.sub(r"[\r\t]+", " ", text)
    text = re.sub(r"\n{2,}", "\n", text)
    text = re.sub(r" {2,}", " ", text)
    return text.strip()


def load_bug_records(csv_path: Path = SEED_CSV_PATH) -> list[BugRecord]:
    if not csv_path.exists():
        raise FileNotFoundError(
            f"Seed dataset not found at {csv_path}. Run "
            f"`python scripts/fetch_sample_data.py` first."
        )
    records = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            records.append(
                BugRecord(
                    id=row["id"],
                    source=row["source"],
                    project=row["project"],
                    component=row["component"],
                    title=clean_text(row["title"]),
                    description=clean_text(row["description"]),
                    severity=row["severity"],
                    status=row["status"],
                    resolution=row["resolution"],
                )
            )
    return records


def chunk_text(text: str, chunk_size: int = CHUNK_SIZE_TOKENS,
                overlap: int = CHUNK_OVERLAP_TOKENS) -> list[str]:
    """Whitespace-token sliding-window chunker with overlap."""
    tokens = text.split()
    if len(tokens) <= chunk_size:
        return [text]
    chunks = []
    start = 0
    while start < len(tokens):
        end = min(start + chunk_size, len(tokens))
        chunks.append(" ".join(tokens[start:end]))
        if end == len(tokens):
            break
        start = end - overlap
    return chunks


def records_to_chunks(records: list[BugRecord]) -> list[Chunk]:
    """
    Bug reports in our dataset are short (title + description), so most
    produce exactly one chunk. Longer descriptions get split via chunk_text
    with overlap, per the RAG design in docs/01_Research_Notes.md §1.3.
    """
    chunks: list[Chunk] = []
    for rec in records:
        full_text = f"{rec.title}\n{rec.description}".strip()
        pieces = chunk_text(full_text)
        metadata = {
            "source": rec.source,
            "project": rec.project,
            "component": rec.component,
            "title": rec.title,
            "severity": rec.severity,
            "status": rec.status,
            "resolution": rec.resolution,
        }
        for i, piece in enumerate(pieces):
            chunks.append(
                Chunk(chunk_id=f"{rec.id}::{i}", bug_id=rec.id, text=piece, metadata=metadata)
            )
    return chunks
