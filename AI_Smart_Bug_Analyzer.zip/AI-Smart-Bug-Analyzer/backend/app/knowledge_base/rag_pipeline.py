"""
Module 2, part D — RAG pipeline: the retrieval half of Retrieval-Augmented
Generation. Embeds an incoming query and returns the top-k most similar
historical defects from the knowledge base.

This is the object the Bug Submission Module calls, and the object every
Milestone-2 agent (Duplicate Detection, Root Cause, Remediation) will call
with different queries/contexts — the interface is deliberately narrow
(`search(query, top_k) -> list[MatchedDefect]`) so it's easy to depend on.
"""
from app.config import EMBEDDING_PROVIDER, DEFAULT_TOP_K, VECTORIZER_PATH
from app.knowledge_base.embeddings import get_embedding_provider
from app.knowledge_base.vector_store import FaissVectorStore
from app.models import MatchedDefect


class RAGPipeline:
    def __init__(self):
        self.embedding_provider = get_embedding_provider(EMBEDDING_PROVIDER)
        if EMBEDDING_PROVIDER == "tfidf":
            self.embedding_provider.load(VECTORIZER_PATH)  # loads persisted TF-IDF vectorizer
        self.vector_store = FaissVectorStore.load()

    def search(self, query: str, top_k: int = DEFAULT_TOP_K) -> list[MatchedDefect]:
        query_vector = self.embedding_provider.embed([query])
        raw_results = self.vector_store.search(query_vector, top_k=top_k)

        matches = []
        seen_bug_ids = set()
        for chunk_id, score, metadata in raw_results:
            bug_id = chunk_id.split("::")[0]
            if bug_id in seen_bug_ids:
                continue  # de-dupe multiple chunks of the same bug
            seen_bug_ids.add(bug_id)
            matches.append(
                MatchedDefect(
                    bug_id=bug_id,
                    source=metadata["source"],
                    project=metadata["project"],
                    component=metadata["component"],
                    title=metadata["title"],
                    severity=metadata["severity"],
                    status=metadata["status"],
                    resolution=metadata["resolution"],
                    similarity_score=round(score, 4),
                )
            )
        return matches
