"""
Module 1 — Bug Submission Module

Accepts a bug report either as pasted text (JSON body) or as an uploaded
.txt/.log file. Auto-detects whether the content is free-form text, a stack
trace, or a log file, extracts structured signals when possible, and (if a
knowledge base is available) immediately retrieves similar historical defects.
"""
import re
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, File, HTTPException, UploadFile, Form

from app.config import ALLOWED_UPLOAD_EXTENSIONS, MAX_UPLOAD_SIZE_BYTES, DEFAULT_TOP_K
from app.models import (
    BugSubmissionRequest,
    CombinedAnalysis,
    ExtractedSignals,
    ReportType,
    SubmittedReport,
)
from app.knowledge_base.rag_pipeline import RAGPipeline
from app.agents.orchestrator import run_pipeline, load_analysis

router = APIRouter(prefix="/api/v1/bugs", tags=["Bug Submission Module"])

_rag_pipeline: Optional[RAGPipeline] = None


def get_rag_pipeline() -> RAGPipeline:
    """Lazily loads the RAG pipeline (index built via scripts/build_index.py)."""
    global _rag_pipeline
    if _rag_pipeline is None:
        _rag_pipeline = RAGPipeline()
    return _rag_pipeline


# --- Stack trace / log detection heuristics -------------------------------

_STACK_TRACE_PATTERNS = [
    re.compile(r"^\s*at\s+[\w.$]+\([\w.]+:\d+\)", re.MULTILINE),      # Java: at pkg.Class.method(File.java:12)
    re.compile(r'File "[^"]+", line \d+', re.MULTILINE),               # Python traceback
    re.compile(r"^\s*at\s+[\w./]+:\d+:\d+", re.MULTILINE),             # JS/Node stack frame
    re.compile(r"panic:.*\n.*goroutine", re.MULTILINE | re.DOTALL),    # Go panic
]

_EXCEPTION_PATTERN = re.compile(
    r"([\w.$]*(?:Exception|Error|Panic|Fault))(?::\s*(.*))?", re.MULTILINE
)

_JAVA_FRAME_PATTERN = re.compile(r"at\s+([\w.$]+)\(([\w.]+):(\d+)\)")

_LOG_LEVEL_PATTERN = re.compile(r"\b(ERROR|WARN|WARNING|INFO|DEBUG|FATAL)\b")
_LOG_LINE_PATTERN = re.compile(
    r"^\s*(?:\[?\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}|\d{2}:\d{2}:\d{2})", re.MULTILINE
)


def detect_report_type(text: str) -> ReportType:
    if any(p.search(text) for p in _STACK_TRACE_PATTERNS):
        return ReportType.STACK_TRACE
    log_line_hits = len(_LOG_LINE_PATTERN.findall(text))
    level_hits = len(_LOG_LEVEL_PATTERN.findall(text))
    if log_line_hits >= 2 or level_hits >= 3:
        return ReportType.LOG
    return ReportType.FREE_TEXT


def extract_signals(text: str, report_type: ReportType) -> ExtractedSignals:
    signals = ExtractedSignals()

    if report_type == ReportType.STACK_TRACE:
        exc_match = _EXCEPTION_PATTERN.search(text)
        if exc_match:
            signals.exception_type = exc_match.group(1)
        frame_match = _JAVA_FRAME_PATTERN.search(text)
        if frame_match:
            signals.top_frame = frame_match.group(1)
            signals.file = frame_match.group(2)
            signals.line = int(frame_match.group(3))

    signals.error_line_count = len(re.findall(r"\b(ERROR|FATAL|Exception|Error)\b", text))
    signals.warning_line_count = len(re.findall(r"\b(WARN|WARNING)\b", text))
    return signals


def _process_submission(title: Optional[str], report_text: str,
                         report_type: Optional[ReportType]) -> SubmittedReport:
    if not report_text.strip():
        raise HTTPException(status_code=422, detail="report_text cannot be empty")

    resolved_type = report_type or detect_report_type(report_text)
    signals = extract_signals(report_text, resolved_type)

    submitted = SubmittedReport(
        title=title,
        report_text=report_text,
        report_type=resolved_type,
        extracted_signals=signals,
    )

    try:
        pipeline = get_rag_pipeline()
        query = (title + "\n" + report_text) if title else report_text
        submitted.retrieved_matches = pipeline.search(query, top_k=DEFAULT_TOP_K)
    except FileNotFoundError:
        # Knowledge base index hasn't been built yet (run scripts/build_index.py).
        # Submission still succeeds; matches are simply empty.
        pass

    # Milestone 2 — automatically run Triage + Log Analysis agents on every
    # submission, using the KB matches just retrieved as shared context, and
    # persist the combined structured output for Milestone 3 to consume.
    submitted.analysis = run_pipeline(
        submission_id=submitted.submission_id,
        report_text=report_text,
        report_type=resolved_type,
        kb_matches=submitted.retrieved_matches,
    )

    return submitted


@router.post("/submit", response_model=SubmittedReport)
def submit_bug_report(payload: BugSubmissionRequest) -> SubmittedReport:
    """Submit a bug report / stack trace / log as pasted text (JSON body)."""
    return _process_submission(payload.title, payload.report_text, payload.report_type)


@router.post("/submit-file", response_model=SubmittedReport)
async def submit_bug_report_file(
    title: Optional[str] = Form(None),
    file: UploadFile = File(...),
) -> SubmittedReport:
    """Submit a bug report / stack trace / log as an uploaded .txt or .log file."""
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED_UPLOAD_EXTENSIONS:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type '{suffix}'. Allowed: {sorted(ALLOWED_UPLOAD_EXTENSIONS)}",
        )

    raw = await file.read()
    if len(raw) > MAX_UPLOAD_SIZE_BYTES:
        raise HTTPException(status_code=413, detail="File too large (max 2 MB)")

    try:
        text = raw.decode("utf-8", errors="replace")
    except Exception:
        raise HTTPException(status_code=400, detail="Could not decode file as UTF-8 text")

    return _process_submission(title, text, None)


@router.get("/{submission_id}/analysis", response_model=CombinedAnalysis)
def get_submission_analysis(submission_id: str) -> CombinedAnalysis:
    """Fetch the persisted Milestone 2 agent analysis for a past submission —
    this is what Milestone 3 agents (Root Cause, Duplicate Detection,
    Remediation) will call instead of re-running Triage/Log Analysis."""
    analysis = load_analysis(submission_id)
    if analysis is None:
        raise HTTPException(status_code=404, detail="No analysis found for this submission_id")
    return analysis
