# AI Smart Bug Analyzer & Fix Advisor

**Infosys Springboard Internship — Milestone 1 & Milestone 2 Submission**
**Milestone 1 period:** 30 June – 9 July 2026
**Milestone 2 period:** 14 – 26 July 2026

An AI-powered, multi-agent system that takes in raw bug reports, stack traces, or
error logs and returns structured, actionable analysis: severity, likely root cause,
duplicate-bug detection against historical data, a recommended fix, and a confidence
score — backed by a Retrieval-Augmented-Generation (RAG) knowledge base built from
historical defect data.

This repository now contains **Milestone 1** (research, architecture, Bug Submission
Module, Historical Defect Knowledge Base/RAG) **and Milestone 2** (Triage Agent, Log
Analysis Agent, multi-agent orchestration, and accuracy validation).

---

## 1. What's inside

```
AI-Smart-Bug-Analyzer/
├── README.md                          <- you are here
├── docs/
│   ├── 01_Research_Notes.md           <- defect workflows, RAG, similarity, bug report structure
│   ├── 02_System_Architecture.md      <- full system design, agents, orchestration, data model
│   ├── 03_Tech_Stack.md               <- tech stack + justification
│   ├── 04_Milestone2_Agent_Design.md  <- Triage/Log Analysis agent design + orchestration
│   └── 05_Milestone2_Validation_Report.md  <- accuracy results (auto-generated)
├── backend/
│   ├── requirements.txt
│   ├── app/
│   │   ├── main.py                    <- FastAPI entrypoint
│   │   ├── config.py
│   │   ├── models.py                  <- Pydantic schemas
│   │   ├── bug_submission.py          <- Module 1: Bug Submission Module
│   │   ├── knowledge_base/
│   │   │   ├── ingest.py              <- loading + cleaning + chunking datasets
│   │   │   ├── embeddings.py          <- embedding provider (pluggable)
│   │   │   ├── vector_store.py        <- FAISS vector index wrapper
│   │   │   └── rag_pipeline.py        <- Module 2: retrieval pipeline
│   │   └── agents/                    <- Milestone 2
│   │       ├── log_analysis_agent.py  <- parses stack traces/logs -> structured signals
│   │       ├── triage_agent.py        <- severity/priority/component + confidence + reasoning
│   │       └── orchestrator.py        <- runs both agents, persists CombinedAnalysis
│   ├── data/
│   │   ├── raw/                       <- seed historical bug datasets
│   │   └── processed/                 <- chunked + indexed data + per-submission analyses (generated)
│   ├── scripts/
│   │   ├── fetch_sample_data.py       <- builds the seed dataset
│   │   ├── build_index.py             <- runs ingestion → chunk → embed → index
│   │   └── validate_agents.py         <- Milestone 2 accuracy validation
│   └── tests/
│       ├── test_api.py                <- Milestone 1 tests
│       └── test_agents.py             <- Milestone 2 tests
└── AI_Smart_Bug_Analyzer.zip          <- zipped deliverable
```

## 2. Milestone 1 deliverables checklist

| Deliverable | Status | Where |
|---|---|---|
| Research & understanding (defect workflows, RAG, similarity, bug report structures) | ✅ Done | `docs/01_Research_Notes.md` |
| System architecture, agent responsibilities, orchestration flow, KB data model | ✅ Done | `docs/02_System_Architecture.md` |
| Tech stack | ✅ Done | `docs/03_Tech_Stack.md` |
| Bug Submission Module (paste + file upload for reports/stack traces/logs) | ✅ Working prototype | `backend/app/bug_submission.py` |
| Historical Defect Knowledge Base + RAG pipeline (collect → chunk → embed → index → retrieve) | ✅ Working prototype | `backend/app/knowledge_base/` |

## 3. Milestone 2 deliverables checklist

| Deliverable | Status | Where |
|---|---|---|
| Triage Agent — severity/priority/component + confidence + reasoning | ✅ Working | `backend/app/agents/triage_agent.py` |
| Log Analysis Agent — exception type, failure point, affected code path, structured frames | ✅ Working | `backend/app/agents/log_analysis_agent.py` |
| Multi-agent orchestration — both agents run automatically on every submission | ✅ Working | `backend/app/agents/orchestrator.py`, wired into `bug_submission.py` |
| Combined output stored in a consistent structure for Milestone 3 | ✅ Working | `backend/data/processed/analyses/{submission_id}.json`, `GET /api/v1/bugs/{id}/analysis` |
| Accuracy validation across varied formats/error types | ✅ Done | `backend/scripts/validate_agents.py` → `docs/05_Milestone2_Validation_Report.md` |
| GitHub repository link | ⬜ **Push this folder and paste the link here** | — |

## 4. Quick start

```bash
cd backend
python -m venv venv && source venv/bin/activate      # optional
pip install -r requirements.txt

# 1. Build the seed historical-defect dataset + vector index
python scripts/fetch_sample_data.py
python scripts/build_index.py

# 2. (Milestone 2) Validate the Triage and Log Analysis agents
python scripts/validate_agents.py

# 3. Run the API
uvicorn app.main:app --reload --port 8000
```

Open **http://127.0.0.1:8000/docs** for interactive Swagger UI to try every module.

## 5. Try it

**Submit a bug report (paste text) — now automatically triaged and log-analyzed:**
```bash
curl -X POST http://127.0.0.1:8000/api/v1/bugs/submit \
  -H "Content-Type: application/json" \
  -d '{"title":"App crashes on save","report_text":"java.lang.NullPointerException at com.app.Save.write(Save.java:42)","report_type":"stack_trace"}'
```
The response now includes an `"analysis"` object with `triage` (severity,
priority, affected_component, confidence, reasoning) and `log_analysis`
(exception_type, failure_point, affected_code_path, stack_frames) — this is
the Milestone 2 output, generated automatically for every submission.

**Submit a bug report (file upload — .txt/.log):**
```bash
curl -X POST http://127.0.0.1:8000/api/v1/bugs/submit-file \
  -F "title=Upload test" -F "file=@/path/to/error.log"
```

**Fetch a past submission's stored analysis (what Milestone 3 will consume):**
```bash
curl http://127.0.0.1:8000/api/v1/bugs/<submission_id>/analysis
```

**Query the RAG knowledge base directly:**
```bash
curl -X POST http://127.0.0.1:8000/api/v1/kb/search \
  -H "Content-Type: application/json" \
  -d '{"query":"NullPointerException on file save", "top_k":5}'
```

Every bug submission automatically runs a KB similarity search, then the
Triage and Log Analysis agents, and persists the combined result to
`data/processed/analyses/{submission_id}.json` — this is exactly what
Milestone 3's agents (Root Cause, Duplicate Detection, Remediation) will
consume in the next milestone, per the note in the milestone brief.

## 6. Publishing to GitHub

```bash
cd AI-Smart-Bug-Analyzer
git init
git add .
git commit -m "Milestone 1 + 2: architecture, bug submission, RAG knowledge base, triage & log analysis agents"
git branch -M main
git remote add origin https://github.com/<your-username>/ai-smart-bug-analyzer.git
git push -u origin main
```

## 7. A note on the historical dataset (important — please read)

Milestone 1 asks for the knowledge base to be seeded from the **Mozilla, Apache,
and Eclipse bug-report datasets on Kaggle**. This sandbox environment's network
access is restricted to package registries only (PyPI, npm, GitHub, crates.io) —
it cannot reach `kaggle.com` or `huggingface.co` to download the datasets or
pretrained embedding models. To still deliver a *fully working* prototype, I did
the following, all clearly isolated so it's a one-line swap for the real data:

- `backend/data/raw/seed_bug_reports.csv` — a hand-built sample of ~60 bug reports
  written in the exact schema of the Mozilla/Apache/Eclipse Kaggle sets
  (`id, source, project, component, title, description, severity, status,
  resolution`), covering realistic categories (NPE, memory leak, race condition,
  UI freeze, build failure, etc.) so ingestion/chunking/embedding/retrieval can be
  demonstrated end-to-end today.
- `backend/scripts/fetch_sample_data.py` has a `download_from_kaggle()` stub with
  the exact `kagglehub`/Kaggle-API calls needed — **uncomment and run this on your
  own machine** (which has normal internet access) to pull the real datasets; the
  rest of the pipeline (`ingest.py`, `build_index.py`) needs zero changes because
  it just expects a CSV in that schema.
- Same story for embeddings: `embeddings.py` implements a clean
  `EmbeddingProvider` interface. The prototype ships a dependency-free `TfidfEmbeddingProvider`
  (no model download required) and a ready-to-enable
  `SentenceTransformerEmbeddingProvider` (`all-MiniLM-L6-v2`) for when you run it
  somewhere with Hugging Face access — swap it in `config.py` with one line.

This is the standard way to handle an offline dev sandbox: build against the real
schema and a realistic sample, keep the "real data source" swap to a single
config change, so nothing about Milestone 2/3 needs to be redesigned once you run
it with full internet access or the actual Kaggle CSVs.
