# Research Notes — Milestone 1, Task 1

## 1.1 Defect Analysis Workflow (how humans currently triage bugs)

A typical enterprise defect lifecycle looks like this:

1. **Report intake** — a tester, user, or monitoring system files a bug: a title,
   free-text description, optionally a stack trace/log, environment info, and
   steps to reproduce.
2. **Triage** — a lead assigns severity (Blocker/Critical/Major/Minor/Trivial) and
   priority, and routes it to the right component owner. This step is highly
   repetitive and pattern-based — which is exactly why it's a good candidate for
   an LLM agent.
3. **Duplicate check** — before anyone invests time, the team checks whether this
   is already reported. In large projects (Mozilla, Apache, Eclipse) duplicate
   reports are extremely common (studies on Bugzilla data put duplicate rates
   around 20–30%), so this step alone saves significant engineering time.
4. **Root cause / log analysis** — the developer reads the stack trace, correlates
   it with recent commits/known issues, and forms a hypothesis about *why* it
   happened (not just *what* happened).
5. **Fix + resolution** — a patch is written, and the bug is marked
   Fixed/WontFix/Duplicate/Invalid, with a resolution note.
6. **Knowledge capture** — the resolved bug (with its resolution) becomes training
   signal for the *next* similar bug. This is the loop our knowledge base
   automates.

Our multi-agent pipeline mirrors steps 2–5 (Triage → Log Analysis → Root Cause →
Duplicate Detection → Remediation), with step 6 implemented as the RAG knowledge
base that every agent can query.

## 1.2 Bug Report / Stack Trace / Log structure

We studied the structure of reports across Bugzilla (Mozilla, Eclipse) and Jira
(Apache) exports. Despite different tools, they converge on the same core fields,
which is what our data model in §2 is built around:

| Field | Bugzilla (Mozilla/Eclipse) | Jira (Apache) | Our unified field |
|---|---|---|---|
| Identifier | `bug_id` | `key` (e.g. `SPARK-1234`) | `id` |
| Project/product | `product` | `project` | `project` |
| Sub-area | `component` | `component` | `component` |
| Title | `short_desc` | `summary` | `title` |
| Body | `long_desc` / comments | `description` | `description` |
| Severity | `bug_severity` | `priority` | `severity` |
| State | `bug_status` | `status` | `status` |
| Outcome | `resolution` | `resolution` | `resolution` |

**Stack traces** follow a language-specific but predictable grammar, e.g. Java:
```
Exception-class: message
	at fully.qualified.Class.method(File.java:line)
	at ... (repeats, innermost cause first)
Caused by: <nested exception> (optional, chained)
```
We exploit this regular structure in the Bug Submission Module to auto-detect
report type (`free_text` vs `stack_trace` vs `log`) and to pull out structured
signals (exception class, top frame, file:line) even before any AI runs.

**Logs** are less structured (timestamp + level + message lines) but still give
us extractable signals: ERROR/WARN density, repeated message patterns, and
timestamps we can use to find the failure window.

## 1.3 RAG (Retrieval-Augmented Generation) architecture

Standard RAG has four stages, which map 1:1 to our knowledge-base module:

1. **Chunking** — split long documents into overlapping windows so each chunk
   fits an embedding model's context and stays topically coherent. For bug
   reports, a natural "chunk" is close to a *whole report* (title+description
   concatenated) since they're already short; for long comment threads we use a
   sliding window (default 300 tokens, 50-token overlap).
2. **Embedding** — map each chunk to a dense vector such that semantically
   similar text ends up nearby in vector space.
3. **Indexing** — store those vectors in a structure that supports fast
   nearest-neighbor search (we use FAISS, an approximate/exact nearest-neighbor
   library — see Tech Stack doc).
4. **Retrieval + augmentation** — at query time, embed the incoming bug report,
   fetch the top-k nearest historical bugs, and hand those (as *context*) to the
   downstream agents so their reasoning is grounded in real historical
   resolutions instead of hallucinated guesses.

RAG is the right fit here (vs. fine-tuning a model on bug data) because:
- The knowledge base needs to grow continuously as new bugs are resolved —
  retrieval-based systems update by just adding vectors, no retraining.
- We need traceability: every recommendation should point back to the specific
  historical bug(s) it's based on, which fine-tuned generation can't guarantee.

## 1.4 Semantic similarity techniques

Options considered for "how similar are two bug reports":

| Technique | How it works | Pros | Cons | Decision |
|---|---|---|---|---|
| Lexical (TF-IDF / BM25) | Weighted word-overlap | Fast, no model download, explainable | Misses paraphrases ("crash" vs "fails") | **Used for Milestone 1 prototype** (see §6 of README for why) |
| Dense embeddings (Sentence-BERT / `all-MiniLM-L6-v2`) | Neural encoder → 384-dim vector, cosine similarity | Captures paraphrase/synonymy | Needs a downloaded pretrained model | **Designed for, pluggable — enable when internet/HF access available** |
| Hybrid (lexical + dense, re-ranked) | Union of both candidate sets, re-ranked by a cross-encoder | Best accuracy | More moving parts | Target for later milestone once agents need higher precision |

We designed `embeddings.py` around an `EmbeddingProvider` interface specifically
so we can start with TF-IDF today and upgrade to dense/hybrid without touching
any other module (vector store, RAG pipeline, or agents).

**Similarity metric:** cosine similarity, which is standard for both TF-IDF and
dense embeddings and is scale-invariant to document length — important since bug
reports vary from one line to several paragraphs.

## 1.5 Sources consulted

- Bugzilla and Jira field/schema documentation (public).
- General knowledge of duplicate-bug-detection literature (e.g. Runeson et al.,
  "Detection of Duplicate Defect Reports Using Natural Language Processing") for
  the ~20–30% duplicate-rate figure and the TF-IDF/cosine baseline approach.
- Standard RAG architecture (Lewis et al., "Retrieval-Augmented Generation for
  Knowledge-Intensive NLP Tasks") for the chunk → embed → index → retrieve
  pattern used throughout.
