# System Architecture — Milestone 1, Task 2

## 2.1 Overall system architecture

```
                              ┌───────────────────────────┐
                              │            User            │
                              └─────────────┬──────────────┘
                                            │ paste text / upload file
                                            ▼
                         ┌──────────────────────────────────┐
                         │      Bug Submission Module        │  (Milestone 1 ✅)
                         │  - accepts text, .txt/.log files   │
                         │  - detects report type             │
                         │  - normalizes into BugReport schema │
                         └───────────────────┬────────────────┘
                                             │
                                             ▼
              ┌───────────────────────────────────────────────────────┐
              │        Historical Defect Knowledge Base (RAG)           │ (Milestone 1 ✅)
              │  Kaggle datasets → clean → chunk → embed → FAISS index  │
              │  exposes: search(query, top_k) -> ranked historical bugs│
              └───────────────────────────┬───────────────────────────┘
                                           │ retrieved context
                                           ▼
                        ┌──────────────────────────────────────┐
                        │        Multi-Agent Pipeline             │  (Milestone 2)
                        │                                         │
                        │   Triage Agent                          │
                        │        │                                │
                        │        ▼                                │
                        │   Log Analysis Agent                    │
                        │        │                                │
                        │        ▼                                │
                        │   Root Cause Agent                      │
                        │        │                                │
                        │        ▼                                │
                        │   Duplicate Detection Agent  ◄───────────┼── queries KB
                        │        │                                │
                        │        ▼                                │
                        │   Remediation Agent          ◄───────────┼── queries KB
                        └───────────────────┬─────────────────────┘
                                            │ structured findings
                                            ▼
                     ┌─────────────────────────────────────────┐
                     │  Structured Findings & Resolution UI      │ (Milestone 3)
                     │  Severity | Root Cause | Duplicates |      │
                     │  Recommended Fix | Confidence Score         │
                     └─────────────────────┬───────────────────┘
                                           │
                                           ▼
                     ┌─────────────────────────────────────────┐
                     │  Defect Pattern Analytics /                │ (Milestone 3/4)
                     │  Systemic Issue Detection Module            │
                     │  (aggregates resolved bugs back into KB)    │
                     └─────────────────────────────────────────┘
```

Milestone 1 delivers the top two boxes end-to-end and working; everything below
is designed now (this document) and built in the following milestones so the
interfaces don't need to change later.

## 2.2 Orchestration flow (sequence)

1. User submits a bug report (paste or file) → **Bug Submission Module**.
2. Module validates + classifies the input (`free_text` / `stack_trace` / `log`),
   extracts structured signals if it's a stack trace (exception class, file:line),
   and stores it as a `BugReport` object with a generated `submission_id`.
3. Module calls **Knowledge Base `search()`** with the report's text → gets back
   the top-k most similar historical defects with similarity scores.
4. *(Milestone 2)* The orchestrator hands `{submitted_report, retrieved_context}`
   to the **Triage Agent**, which passes its output + context down the chain to
   Log Analysis → Root Cause → Duplicate Detection → Remediation. Each agent
   *reads* the shared context and *appends* its own structured output — this is
   a **linear pipeline with shared blackboard state**, not agents debating each
   other, which keeps behavior predictable and each agent's output independently
   testable.
5. Final structured findings are returned to the UI and also written back into
   the knowledge base once the bug is resolved (closing the loop, §1.1 step 6).

## 2.3 Agent responsibilities (design for Milestone 2, specified now per Milestone-1 ask)

| Agent | Input | Responsibility | Output |
|---|---|---|---|
| **Triage Agent** | Raw submitted report + KB context | Classify severity/priority, route to likely component, decide if it even needs deeper analysis (e.g. reject spam/empty reports) | `{severity, priority, component, needs_deep_analysis}` |
| **Log Analysis Agent** | Report text, extracted stack-trace/log signals | Parse stack trace / log lines, identify the exception type, failing module, and the sequence of events leading to failure | `{exception_type, failure_point, key_log_lines}` |
| **Root Cause Agent** | Output of Log Analysis + KB context (similar past root causes) | Form a hypothesis of *why* the failure happened, grounded in retrieved similar historical resolutions | `{root_cause_hypothesis, supporting_evidence, confidence}` |
| **Duplicate Detection Agent** | Submitted report + KB search results | Decide whether this is a duplicate of an existing bug using similarity score thresholds + status of the matched bug | `{is_duplicate, duplicate_of[], similarity_score}` |
| **Remediation Agent** | All prior agents' outputs + KB resolutions of similar bugs | Recommend a concrete fix approach, referencing how similar historical bugs were resolved | `{recommended_fix, referenced_resolutions[], confidence}` |

**Why this order:** Triage first (cheap, decides if we even continue),
Log Analysis before Root Cause (root cause needs parsed signals, not raw text),
Duplicate Detection before Remediation (no point recommending a fix if it's a
known duplicate — we'd rather point to the existing resolution).

## 2.4 Knowledge base data model

**Source record** (as ingested from Mozilla/Apache/Eclipse datasets):

```
BugRecord
├── id                str   (e.g. "MOZ-10432", "SPARK-1234")
├── source             str   (mozilla | apache | eclipse)
├── project            str   (e.g. "Firefox", "Spark", "Eclipse Platform")
├── component           str
├── title               str
├── description         str
├── severity            str  (blocker | critical | major | minor | trivial)
├── status              str  (open | resolved | closed | reopened)
├── resolution          str  (fixed | duplicate | wontfix | invalid | worksforme)
└── duplicate_of        str | null
```

**Chunk record** (unit stored in the vector index — one or more per BugRecord):

```
Chunk
├── chunk_id            str    (f"{bug_id}::{chunk_index}")
├── bug_id              str    (FK -> BugRecord.id)
├── text                str    (title + description window)
├── metadata            dict   (source, project, component, severity, resolution)
└── embedding           float[]  (dense or sparse vector, dimension depends on provider)
```

**Vector index:** FAISS `IndexFlatIP` (inner product on L2-normalized vectors =
cosine similarity) mapping `chunk_id -> embedding`, with a parallel
`chunk_id -> Chunk metadata` lookup table (kept as JSON for Milestone 1 simplicity;
swappable for a real metadata DB like Postgres later without touching the index
interface).

**Submitted report record** (from the Bug Submission Module):

```
SubmittedReport
├── submission_id        str   (UUID, generated)
├── title                 str | null
├── report_text           str
├── report_type            str   (free_text | stack_trace | log)
├── extracted_signals      dict  (exception_type, top_frame, file, line — if detected)
├── submitted_at            datetime
└── retrieved_matches[]     Chunk[]   (populated after KB search)
```

This is exactly the schema implemented in `backend/app/models.py`.

## 2.5 Why a linear "blackboard" pipeline instead of a fully autonomous agent graph

For a system whose output feeds into engineering decisions, we prioritized
**determinism and debuggability** over flexibility: each agent's contract
(input → output shape) is fixed and independently testable, the RAG retrieval
step is shared and computed once (not re-queried differently by every agent), and
adding a new agent later just means inserting another stage in the pipeline
without redesigning message-passing. If a future milestone needs agents to loop
back (e.g. Root Cause asking Log Analysis to re-parse with a new hint), that's
an explicit, logged retry — not implicit multi-agent chatter.
