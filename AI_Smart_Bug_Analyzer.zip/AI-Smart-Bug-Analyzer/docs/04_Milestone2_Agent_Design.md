# Milestone 2 — Triage Agent & Log Analysis Agent Design

## 1. Multi-agent orchestration flow

```
Bug Submission Module (Milestone 1)
        │  report_text, report_type
        ▼
Historical Defect KB / RAG search (Milestone 1)   -> kb_matches
        │
        ▼
┌─────────────────────────────┐
│   Log Analysis Agent          │  runs FIRST — Triage needs its exception_type
│   (report_text, report_type)  │  as one of its input signals.
└──────────────┬────────────────┘
               │ LogAnalysisResult
               ▼
┌─────────────────────────────┐
│   Triage Agent                 │  consumes: report_text, LogAnalysisResult,
│                                 │  kb_matches
└──────────────┬────────────────┘
               │ TriageResult
               ▼
     CombinedAnalysis  (persisted to
     data/processed/analyses/{submission_id}.json)
               │
               ▼
     Milestone 3 agents (Root Cause, Duplicate Detection, Remediation)
     read this file directly — no re-parsing, no re-running Triage/Log Analysis.
```

This is the "linear pipeline with shared blackboard state" design committed to
in `docs/02_System_Architecture.md` §2.5: each agent's input/output is a fixed,
independently testable contract (`app/models.py`), and the orchestrator
(`app/agents/orchestrator.py`) is the only thing that knows the run order.

## 2. Log Analysis Agent

**Goal:** turn a raw stack trace / log / free-text report into structured
signals: `exception_type`, `failure_point`, `affected_code_path`,
`stack_frames[]`, a one-line `error_summary`, and a `confidence_score`.

**Approach:** a small per-language grammar parser for each stack-trace dialect
we researched in `docs/01_Research_Notes.md` §1.2 — Java, Python, JavaScript
/TypeScript, and Go — tried in sequence; the first one whose frame pattern
matches "wins" (a report can only match one language's frame grammar in
practice, since they're structurally distinct). If none match, we fall back to
scanning for `ERROR`/`FATAL`/`WARN` log lines, and finally to a generic
free-text summary with low confidence.

**Why regex/grammar parsing instead of an LLM call:** stack traces are a
*formal, regular* structure (see §1.2) — a deterministic parser is exactly as
accurate as a language model for extracting `file:line`, is instant, needs no
API key or network call, and (crucially for a milestone review) gives 100%
reproducible output for the same input. We reserve LLM reasoning for genuinely
ambiguous judgment calls — which is exactly what the Triage Agent needs to do,
and why it's built differently (see §3).

**Per-language notes:**
- **Java**: `at pkg.Class.method(File.java:line)` frames, innermost frame is
  *first* in the trace → `stack_frames[0]` is the failure point.
- **Python**: `File "x.py", line N, in func` frames, innermost frame is
  *last* in the trace (opposite convention from Java) → `stack_frames[-1]` is
  the failure point. The *last* matching exception line is used (Python
  reprints the exception type at the very end, after any chained-exception
  headers).
- **JavaScript/TypeScript**: `at func (file.js:line:col)` — same
  first-frame-is-innermost convention as Java.
- **Go**: `panic: message` plus `file.go:line` frames from the goroutine dump.

## 3. Triage Agent

**Goal:** classify `severity` (Critical/High/Medium/Low), derive `priority`
(P0-P3), guess the `affected_component`, and give a `confidence_score` with
`reasoning` a human triager could sanity-check.

**Approach — three independent signals, combined by vote, not by a single
score:**

| Signal | Source | What it captures |
|---|---|---|
| Keyword signal | Regex/keyword match over the raw report text | Severity-indicative language ("crash", "data loss", "cosmetic", ...) |
| Exception signal | The Log Analysis Agent's `exception_type` | A fixed mapping of known exception/error classes to typical severity (e.g. `OutOfMemoryError` → Critical, `NullPointerException` → High) |
| KB signal | Milestone 1's RAG retrieval (`kb_matches`) | Majority severity (similarity-weighted) among the most similar historical defects, plus majority component for `affected_component` |

**Why vote instead of "most confident single signal":** any one signal alone
is noisy — keyword matching is easily fooled by phrasing, a single exception
type maps to different real-world severities depending on context, and KB
retrieval quality depends on TF-IDF vocabulary overlap (see
`docs/03_Tech_Stack.md` for why TF-IDF was used for Milestone 1/2 and how to
upgrade it). Requiring agreement across independent signals is a cheap, fully
explainable way to get a genuine confidence estimate instead of a single
model's raw (often overconfident) output.

**Tie-break policy:** when signals disagree with no majority, we resolve
toward the *more* severe outcome — it is safer to over-triage a bug that turns
out to be minor than to under-triage a real critical bug into a low-priority
backlog. This is stated explicitly in the `reasoning` string whenever it
happens (see `docs/05_Milestone2_Validation_Report.md` for an example).

**Confidence formula:**
```
confidence = min(0.95, 0.35 + 0.35 * agreement + 0.10 * num_signals_fired)
```
where `agreement` is the fraction of fired signals that match the winning
severity. This rewards both *consensus* (agreement) and *having more than one
independent signal to check* (num_signals_fired) — a single signal firing in
isolation caps confidence well below what three agreeing signals would give.

## 4. Combined, persisted output (contract for Milestone 3)

```jsonc
{
  "submission_id": "...",
  "triage": {
    "severity": "High", "priority": "P1", "affected_component": "CacheManager",
    "confidence_score": 0.95, "reasoning": "..."
  },
  "log_analysis": {
    "exception_type": "java.lang.NullPointerException",
    "failure_point": "com.app.CacheManager.writeToDisk",
    "affected_code_path": "CacheManager.java",
    "stack_frames": [ { "class_or_function": "...", "file": "...", "line": 42, "raw": "..." } ],
    "error_summary": "...", "confidence_score": 0.9
  },
  "analyzed_at": "..."
}
```
Persisted at `backend/data/processed/analyses/{submission_id}.json` and
retrievable via `GET /api/v1/bugs/{submission_id}/analysis`. Milestone 3's
Root Cause, Duplicate Detection, and Remediation agents are expected to read
this file/endpoint rather than re-deriving any of it.

## 5. Validation methodology and results

See `docs/05_Milestone2_Validation_Report.md` (generated by
`scripts/validate_agents.py`) for full numbers. Summary:

- **Log Analysis Agent**: 100% exception-type, file, and line accuracy across
  6 hand-built test cases spanning Java, Python, JavaScript, Go, plain logs,
  and free text — the deterministic-parser approach performs exactly as
  designed on well-formed input in each supported grammar.
- **Triage Agent**: 67.8% severity accuracy on the full 90-record seeded
  dataset. The confusion matrix in the validation report shows most errors are
  "Medium (ground truth) → High (predicted)" — i.e. the agent is currently
  biased toward over-estimating severity when the KB signal dominates and text
  keywords are absent, which is a direct, understood consequence of the
  tie-break/vote design (§3) and the TF-IDF retrieval quality documented as a
  known limitation in Milestone 1. This is flagged, not hidden, in the
  validation report's "Notes / known limitations" section, along with the
  concrete next step (dense embeddings) that should improve it.
