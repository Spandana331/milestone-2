# Tech Stack — Milestone 1

| Layer | Choice | Why |
|---|---|---|
| API framework | **FastAPI** (Python) | Async, automatic OpenAPI/Swagger docs (`/docs`), native Pydantic validation — ideal for a module-by-module milestone delivery where each module is its own router. |
| Language | **Python 3.11+** | Dominant ecosystem for RAG/ML tooling (embeddings, vector search, future LLM agent frameworks). |
| Data validation | **Pydantic v2** | Enforces the `BugReport` / `Chunk` schemas from the architecture doc at runtime; auto-generates API docs. |
| File upload handling | **python-multipart** (via FastAPI `UploadFile`) | Standard, no extra service needed for `.txt`/`.log` uploads. |
| Text preprocessing / chunking | **Plain Python + regex** | Bug reports are short; a lightweight custom chunker (sliding window with overlap) avoids an unnecessary heavy dependency for Milestone 1. |
| Embeddings (Milestone 1 default) | **scikit-learn `TfidfVectorizer`** | Zero model download required (works fully offline in any sandbox/CI), fast, explainable — appropriate baseline per the similarity-technique comparison in the Research Notes. |
| Embeddings (pluggable upgrade path) | **`sentence-transformers` / `all-MiniLM-L6-v2`** | Designed behind the same `EmbeddingProvider` interface; enable with one config change once running with Hugging Face network access. |
| Vector store | **FAISS (`faiss-cpu`)** | Industry-standard, in-process (no separate DB server to run for a milestone demo), `IndexFlatIP` gives exact cosine-similarity search which is plenty fast at this data scale; interface is swappable for Chroma/Pinecone/Weaviate later without touching the RAG pipeline code. |
| Historical dataset | Mozilla / Apache / Eclipse bug reports (Kaggle) — **seeded with a schema-matched sample** in this sandbox; script provided to pull the real Kaggle CSVs on a machine with internet access (see README §6) | Requested by the milestone brief. |
| Testing | **pytest** | Standard Python testing; `tests/test_api.py` covers both modules. |
| Packaging | **`requirements.txt`** (pip) | Simple, no extra tooling needed for a milestone-sized project. |
| Future (Milestone 2+) | **LLM orchestration** — LangGraph or a lightweight custom orchestrator; **LLM provider** — Anthropic Claude API for the reasoning agents (Triage/Log Analysis/Root Cause/Remediation) | Agents need an actual LLM call once we move past retrieval into reasoning/generation; kept out of Milestone 1 scope per the brief (Milestone 1 = submission module + knowledge base only). |
| Future (Milestone 3+) | React frontend for the Structured Findings dashboard | Out of scope for Milestone 1 (backend/API-only milestone). |

## Why not a hosted vector DB / hosted embedding API for Milestone 1?

Keeping everything in-process (FAISS + TF-IDF) means the entire Milestone 1
deliverable runs with `pip install -r requirements.txt` and no API keys, no
external services, and no network dependency — which matters for a reviewer
who just wants to clone the repo and run it. The architecture (§2.4/2.5 in the
architecture doc) is deliberately designed so none of this is a dead end: every
piece has a documented, config-level swap to the production-grade option.
